const express = require('express')
const routerMhs = express.Router()
const ctrMhs = require("../controllers/mahasiswa")
const ctrUser = require("../controllers/user")

routerMhs.get('/mahasiswa', ctrUser.authenticate, ctrMhs.getMhs );


routerMhs.post('/mahasiswa', ctrMhs.post );

routerMhs.get('/:nim', ctrMhs.getMhsByNim);

routerMhs.put('/:nim', ctrMhs.update )

routerMhs.delete('/:nim', ctrMhs.delete)

module.exports = routerMhs;